# SQL Gamification Project - Shaismeer

## Project Overview
This project is designed for junior and senior Computer Science students to gamify learning of T-SQL through SQLNOIR mysteries and real-world business scenarios.

## Tools Used
- SQL Server Management Studio (SSMS)
- Azure Data Studio / VSCode

## Database
- Northwind / AdventureWorks

## Components

### 1. Individual SQLNOIR Mysteries
- 10 mysteries
- Each includes 4 sections and final optimized query

### 2. Pair Work Sessions
- 10 sessions
- Business problem solving with SQL

## Goals
- Improve SQL skills (CTEs, joins, subqueries, window functions)
- Develop teamwork and problem-solving
- Simulate real-world data analysis

## Student
Shaismeer
