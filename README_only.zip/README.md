# SQL Gamification Project - Shaismeer

This project focuses on T-SQL learning through SQLNOIR mysteries and business problem-solving.

Student: Shaismeer
