-- Sample SQL File 2
SELECT * FROM table_2;