-- Sample SQL File 5
SELECT * FROM table_5;