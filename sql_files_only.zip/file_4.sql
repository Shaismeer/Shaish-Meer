-- Sample SQL File 4
SELECT * FROM table_4;