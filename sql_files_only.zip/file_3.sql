-- Sample SQL File 3
SELECT * FROM table_3;