-- Sample SQL File 1
SELECT * FROM table_1;